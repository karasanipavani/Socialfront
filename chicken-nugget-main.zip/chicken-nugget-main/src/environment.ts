export const environment = {
    domain: 'https://chicken-nugget-latest.onrender.com'
}