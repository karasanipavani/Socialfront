import { Component } from '@angular/core';
import { UserAuthService } from './userAuth/userAuth.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrl: './app.component.css'
})
export class AppComponent {
    title = 'chicken-nugget';

    constructor(private authService: UserAuthService) { }

    ngOnInit() {
        this.authService.clearAuthToken();
        this.authService.setAuthTokenFromCookie();
    }
}
