import { Component, OnInit } from '@angular/core';
import { UserAuthService } from '../../userAuth.service';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/authService';


@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css'],
})

export class LoginComponent implements OnInit {

    userName: String = "";
    password: String = "";
    loginError: String = "";

    constructor(private userAuthService: UserAuthService, private router: Router, private authService: AuthService) { }

    ngOnInit() {
        if(this.userAuthService.isLoggedIn()) {
            this.router.navigate(['']);
        }
    }

    login() {
        this.authService.login(this.userName, this.password).subscribe(
            (response) => {
                console.log(response)
                const authToken = response;
                // this.userAuthService.setAuthToken(authToken);
                // this.router.navigate(['']);
            },
            (error) => {
                this.loginError = error
                console.error('Authentication error:', error);
            }
        );
        const authToken = 'your-auth-token';
    }

}