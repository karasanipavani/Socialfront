import { Inject, Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';

@Injectable({
    providedIn: 'root'
})
export class UserAuthService {

    authToken: any;

    constructor(private cookieService: CookieService) { 
    }

    getAuthToken(): string {
        return this.authToken;
    }

    setAuthToken(authToken: string) {
        console.log(authToken, "set")
        this.authToken = authToken
        this.cookieService.set('authToken', authToken);
    }

    setAuthTokenFromCookie() {
        this.authToken = this.cookieService.get('authToken');
    }

    clearAuthToken() {
        this.authToken = null;
        this.cookieService.delete('authToken');
    }

    isLoggedIn(): boolean {
        return !!this.authToken;
    }
}
