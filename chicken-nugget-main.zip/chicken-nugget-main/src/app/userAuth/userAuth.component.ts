import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-userAuth',
    templateUrl: './userAuth.component.html',
    styleUrls: ['./userAuth.component.css']
})

export class UserAuthComponent implements OnInit {
    ngOnInit() {
    }

    // logout() {
    //     this.cookieService.delete('authToken');
    // }

}