// userAuth.module.ts
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PostManagementComponent } from './postManagement.component';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { PostViewComponent } from './postView/postView.component';

const postManagementRoutes: Routes = [
    { path: '', component: HomeComponent },
    { path: 'post/:id', component: PostViewComponent}
];

@NgModule({
    declarations: [
        PostManagementComponent,
        HomeComponent,
        PostViewComponent
    ],
    imports: [
        CommonModule,
        RouterModule.forChild(postManagementRoutes)
    ],
    exports: [
        PostManagementComponent,
        HomeComponent,
        PostViewComponent
    ]
})
export class PostMangementModule { }