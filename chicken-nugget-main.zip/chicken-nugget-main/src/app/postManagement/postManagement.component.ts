import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-postManagemetn',
    templateUrl: './postManagement.component.html',
    styleUrls: ['./postManagement.component.css']
})

export class PostManagementComponent implements OnInit {
    ngOnInit() {
    }

}