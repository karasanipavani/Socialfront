import axios from 'axios';
import { Request, Response } from 'express';
import { environment } from '../../environment';

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class AuthService {
    private apiUrl = 'https://example.com/api/authenticate';

    constructor(private http: HttpClient) { }
    login(username: String, password: String) {
        return this.http.post(environment.domain + '/login', { username, password });
    }
}


// export const authController = {
//     async login(req: Request, res: Response) {
//         try {
//             const { username, password } = req.body;
            
//             const response = await axios.post(environment.domain + '/login', {
//                 username,
//                 password
//             });
//             res.json(response.data);
//         } catch (error) {
//             console.error('Error:', error);
//             res.status(500).json({ error: 'Internal Server Error' });
//         }
//     },

//     async resigter(req: Request, res: Response) {
//         try {
//             const { username, password } = req.body;
            
//             const response = await axios.post(environment.domain + 'signUp', {
//                 username,
//                 password
//             });
//             res.json(response.data);
//         } catch (error) {
//             console.error('Error:', error);
//             res.status(500).json({ error: 'Internal Server Error' });
//         }
//     }
// };
